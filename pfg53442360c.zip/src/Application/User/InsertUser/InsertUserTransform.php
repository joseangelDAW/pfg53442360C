<?php
/**
 * Created by PhpStorm.
 * User: jose
 * Date: 8/05/18
 * Time: 17:12
 */

namespace App\Application\User\InsertUser;

class InsertUserTransform implements InsertUserTransformInterface
{

}