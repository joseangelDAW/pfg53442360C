<?php
/**
 * Created by PhpStorm.
 * User: jose
 * Date: 8/05/18
 * Time: 17:13
 */

namespace App\Application\User\InsertUser;


interface InsertUserTransformInterface
{

}