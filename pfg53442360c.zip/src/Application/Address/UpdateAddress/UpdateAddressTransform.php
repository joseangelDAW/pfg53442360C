<?php
/**
 * Created by PhpStorm.
 * User: jose
 * Date: 13/05/18
 * Time: 17:52
 */

namespace App\Application\Address\UpdateAddress;


class UpdateAddressTransform implements UpdateAddressTransformInterface
{
    public function transform(array $input): array
    {

    }
}