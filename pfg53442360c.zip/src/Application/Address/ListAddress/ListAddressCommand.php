<?php
/**
 * Created by PhpStorm.
 * User: jose
 * Date: 8/05/18
 * Time: 17:10
 */

namespace App\Application\Address\ListAddress;


class ListAddressCommand
{

}