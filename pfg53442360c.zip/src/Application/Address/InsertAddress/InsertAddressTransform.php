<?php
/**
 * Created by PhpStorm.
 * User: jose
 * Date: 8/05/18
 * Time: 17:11
 */

namespace App\Application\Address\InsertAddress;


class InsertAddressTransform implements InsertAddressTransformInterface
{

}