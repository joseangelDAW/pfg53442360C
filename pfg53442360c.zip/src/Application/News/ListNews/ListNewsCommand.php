<?php
/**
 * Created by PhpStorm.
 * User: programador
 * Date: 30/05/18
 * Time: 10:07
 */

namespace App\Application\News\ListNews;

class ListNewsCommand
{
}