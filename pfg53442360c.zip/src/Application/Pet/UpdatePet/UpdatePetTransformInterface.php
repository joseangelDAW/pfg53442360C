<?php
/**
 * Created by PhpStorm.
 * User: programador
 * Date: 17/05/18
 * Time: 8:59
 */

namespace App\Application\Pet\UpdatePet;

interface UpdatePetTransformInterface
{
    public function transform();
}