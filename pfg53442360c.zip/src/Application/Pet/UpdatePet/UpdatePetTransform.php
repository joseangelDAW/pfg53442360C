<?php
/**
 * Created by PhpStorm.
 * User: programador
 * Date: 17/05/18
 * Time: 9:00
 */

namespace App\Application\Pet\UpdatePet;

class UpdatePetTransform implements UpdatePetTransformInterface
{
    public function transform()
    {
        // TODO: Implement transform() method.
    }
}