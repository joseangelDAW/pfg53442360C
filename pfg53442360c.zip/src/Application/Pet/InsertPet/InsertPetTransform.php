<?php
/**
 * Created by PhpStorm.
 * User: jose
 * Date: 16/05/18
 * Time: 19:36
 */

namespace App\Application\Pet\InsertPet;


class InsertPetTransform implements InsertPetTransformInterface
{
    public function transform(array $input): array
    {
        // TODO: Implement transform() method.
    }

}