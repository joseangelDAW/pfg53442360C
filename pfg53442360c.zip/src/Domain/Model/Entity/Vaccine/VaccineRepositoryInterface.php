<?php
/**
 * Created by PhpStorm.
 * User: jose
 * Date: 5/05/18
 * Time: 10:27
 */

namespace App\Domain\Model\Entity\Vaccine;


interface VaccineRepositoryInterface
{

}