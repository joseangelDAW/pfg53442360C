<?php
/**
 * Created by PhpStorm.
 * User: jose
 * Date: 19/05/18
 * Time: 10:20
 */

namespace App\Domain\Model\Entity\User;


class UserConst
{
    const OK_LOGIN = 'Login satisfactorio';
    const OK_LOGIN_CODE = 200;

    const ID = 'id';
    const EMAIL = 'email';
    const NICKNAME = 'nickname';
    const PASSWORD = 'password';
}