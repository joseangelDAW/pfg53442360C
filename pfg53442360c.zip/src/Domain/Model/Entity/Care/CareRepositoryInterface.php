<?php
/**
 * Created by PhpStorm.
 * User: jose
 * Date: 5/05/18
 * Time: 10:13
 */

namespace App\Domain\Model\Entity\Care;


interface CareRepositoryInterface
{

}